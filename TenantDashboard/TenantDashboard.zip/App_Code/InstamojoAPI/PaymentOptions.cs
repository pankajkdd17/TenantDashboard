﻿namespace InstamojoAPI
{
   public class PaymentOptions
    {
       public string payment_url { get; set; }
    }
}
