﻿namespace InstamojoAPI
{
    public class CreateRefundResponce
    {
        public Refund refund { get; set; }
        public bool success { get; set; }
    }
}
