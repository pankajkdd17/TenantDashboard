﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboard_TenantsMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Request.Cookies["UserDetails"] != null)
        {
            //string s_mobileno = Request.Cookies["UserDetails"]["s_mobile"];
            //string s_fullname = Request.Cookies["UserDetails"]["s_fullname"];
            //string s_email = Request.Cookies["UserDetails"]["s_email"];
            //string s_gender = Request.Cookies["UserDetails"]["s_gender"];
            //string s_photo = Request.Cookies["UserDetails"]["s_photo"];
            string s_photoPath = Request.Cookies["UserDetails"]["s_photoPath"];
            lblmobile.Text = Request.Cookies["UserDetails"]["s_mobile"];
            lblName.Text = Request.Cookies["UserDetails"]["s_fullname"];
            if ((s_photoPath.ToString() != string.Empty) && (Request.Cookies["UserDetails"]["s_photoPath"] != null))
            {
                Image1.ImageUrl = Request.Cookies["UserDetails"]["s_photoPath"];
            }
            else
            {
                Image1.ImageUrl = "~/Dashboard/images/defaulticon.png";
            }
        }
        else
        {
            Response.Redirect("~/Dashboard/login.aspx");
        }
    }



    protected void lbtnLogout_Click(object sender, EventArgs e)
    {
        Response.Cookies["UserDetails"].Expires = DateTime.Now.AddYears(-1);
        Response.Redirect("~/Dashboard/login.aspx");
    }
}
