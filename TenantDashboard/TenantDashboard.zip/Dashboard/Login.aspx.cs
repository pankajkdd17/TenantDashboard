﻿using ConnectionString;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboard_Login : System.Web.UI.Page
{
    AddUsers us = new AddUsers();
    GeneralFunctions.GeneralFunctions Gf = new GeneralFunctions.GeneralFunctions();
    static int sentOtp = 0;
    DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (HttpContext.Current.Request.Cookies["UserDetails"] != null)
            {
                txtMobile.Text = Request.Cookies["UserDetails"]["s_mobile"];
            }
            else
            {
                Response.Cookies["UserDetails"].Expires = DateTime.Now.AddYears(-1);
            }
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            if ((txtMobile.Text.Length > 0) && (txtOtp.Text.Length > 0))
            {
                if ((ViewState["Result"].ToString() == "Successful") && (ViewState["OTP"] != null))
                {
                    if (ViewState["Mobile"] != null)
                    {
                        string mobile = ViewState["Mobile"].ToString();
                        if (mobile == txtMobile.Text.Trim())
                        {
                            if (ViewState["OTP"].ToString() == txtOtp.Text)
                            {

                                SqlDataReader sdr = us.GetSignupDetails(mobile);
                                if (sdr.HasRows)
                                {
                                    if (sdr.Read())
                                    {
                                        HttpCookie cookie = new HttpCookie("UserDetails");
                                        cookie.Values.Add("s_mobile", sdr["s_mobile"].ToString());
                                        cookie.Values.Add("s_fullname", sdr["s_fullname"].ToString());
                                        cookie.Values.Add("s_email", sdr["s_email"].ToString());
                                        cookie.Values.Add("s_gender", sdr["s_gender"].ToString());
                                        cookie.Values.Add("s_photo", sdr["s_photo"].ToString());
                                        cookie.Values.Add("s_photoPath", sdr["s_photoPath"].ToString());
                                        cookie.Expires = DateTime.Now.AddYears(1);
                                        Response.Cookies.Add(cookie);

                                        //get the values out
                                        string s_mobileno = Request.Cookies["UserDetails"]["s_mobile"];
                                        string s_fullname = Request.Cookies["UserDetails"]["s_fullname"];
                                        string s_email = Request.Cookies["UserDetails"]["s_email"];
                                        string s_gender = Request.Cookies["UserDetails"]["s_gender"];
                                        string s_photo = Request.Cookies["UserDetails"]["s_photo"];
                                        string s_photoPath = Request.Cookies["UserDetails"]["s_photoPath"];
                                        ViewState.Remove("OTP");
                                        Response.Redirect("~/Dashboard/Index.aspx");
                                    }
                                    sdr.Close();
                                }
                            }
                            else
                            {
                                lblmessage.Text = "Your nomber not OTP Verify";
                                lblmessage.ForeColor = System.Drawing.Color.Red;
                            }
                        }
                        else
                        {
                            lblmessage.Text = "OTP / Mobile  does not matches";
                            lblmessage.ForeColor = System.Drawing.Color.Red;
                        }
                    }
                    else
                    {
                        lblError.Text = "Enter your mobile";
                        lblmessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
            }
            else
            {
                lblError.Text = "Please enter valid mobile / OTP !";

            }

        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message.ToString();
        }
    }

    protected void lbtnSendeOtp_Click(object sender, EventArgs e)
    {
        try
        {

            if (txtMobile.Text.Length > 0)
            {
                string numbers = txtMobile.Text;
                SqlDataReader sdr = us.GetSignupDetails(numbers);
                if (sdr.HasRows)
                {
                    if (sdr.Read())
                    {
                        string Mobile = sdr["s_mobile"].ToString();
                        ViewState["Mobile"] = sdr["s_mobile"].ToString();
                        SendOtp(Mobile);
                    }
                }
                else
                {
                    lblmessage.Text = "You are not added as Tenants!";
                    lblmessage.ForeColor = System.Drawing.Color.Red;
                }
            }
            else
            {
                lblmessage.Text = "Enter valid mobile!";
                lblmessage.ForeColor = System.Drawing.Color.Red;

            }
        }
        catch (Exception ex)
        {
            lblmessage.Text = ex.Message.ToString();
            lblmessage.ForeColor = System.Drawing.Color.Red;
        }
    }
    public void SendOtp(string Mobile)
    {
        Random rand = new Random();
        string sentOtp = (rand.Next(100000, 999999)).ToString();
        string sentOtpText = "" + sentOtp + " is your OTP to login to your stayello platform. It is valid for next 10 minutes";
        string senders = "STAYLO";
        String url = "http://37.59.76.46/api/mt/SendSMS?user=STAYLO&password=8604@sms&senderid=" + senders + "&channel=TRANS&DCS=0&flashsms=0&number=" + Mobile + "&text=" + sentOtpText + "&route=02";
        ViewState["OTP"] = sentOtp;
        try
        {
            HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
            System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
            string responseString = respStreamReader.ReadToEnd();
            respStreamReader.Close();
            myResp.Close();
            lblmessage.Text = "OTP Sent Successfully";
            lblmessage.ForeColor = System.Drawing.Color.Green;
            lblmessage.Visible = true;
            lbtnSendeOtp.Text = "Resend OTP";
            txtOtp.Text = string.Empty;
            // lbtnSendeOtp.BackColor = Color.Green;
            // txtMobile.ReadOnly = true;
            ViewState["Result"] = "Successful";
        }
        catch (Exception ex)
        {
            lblmessage.Text = ex.Message.ToString();
            lblmessage.ForeColor = System.Drawing.Color.Blue;
            txtOtp.Text = string.Empty;
            lblmessage.Visible = true;
            lbtnSendeOtp.Text = "Resend Otp";
            lbtnSendeOtp.BackColor = Color.Green;
            ViewState["Result"] = "Unuccessful";
        }
    }

}